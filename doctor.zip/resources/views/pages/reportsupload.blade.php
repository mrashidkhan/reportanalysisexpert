@extends('layout.master')

@section('content')


    

@include('medical-reports.upload')


@endsection

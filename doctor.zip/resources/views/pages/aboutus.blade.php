@extends('layout.master')

@section('content')


     @include('partials.aboutsection')




@endsection

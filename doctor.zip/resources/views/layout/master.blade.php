@include('partials.head')
@include('partials.header')


@yield('content')

@include('partials.footer')
@include('partials.scriptsection')

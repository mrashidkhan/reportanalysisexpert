{{-- @extends('layout.mastersubpage') --}}
@extends('layout.master')

@section('content')


     @include('partials.departments')




@endsection

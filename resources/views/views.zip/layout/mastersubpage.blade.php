@include('partials.head')
@include('partials.headersub')


@yield('content')

@include('partials.footer')
@include('partials.scriptsection')

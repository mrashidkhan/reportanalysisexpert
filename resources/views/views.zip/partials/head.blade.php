<!DOCTYPE html>
<html>


<!-- Mirrored from themewagon.github.io/orthoc/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 02 Jun 2025 14:09:32 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  {{-- <link rel="shortcut icon" href="images/favicon.png" type=""> --}}
  <link rel="shortcut icon" href="{{ asset('asset/images/favicon.png') }}" type="image/png">

  <title> Report Analysis Expert </title>

  <!-- bootstrap core css -->
  {{-- <link rel="stylesheet" type="text/css" href="css/bootstrap.css" /> --}}
  <link rel="stylesheet" type="text/css" href="{{ asset('asset/css/bootstrap.css') }}" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&amp;display=swap" rel="stylesheet">

  <!--owl slider stylesheet -->
  {{-- <link rel="stylesheet" type="text/css" href="../../cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" /> --}}
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- font awesome style -->
  {{-- <link href="css/font-awesome.min.css" rel="stylesheet" /> --}}
  <link href="{{ asset('asset/css/font-awesome.min.css') }}" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="{{ asset('asset/css/style.css') }}" rel="stylesheet" />
  <!-- responsive style -->
  <link href="{{ asset('asset/css/responsive.css') }}" rel="stylesheet" />

</head>


